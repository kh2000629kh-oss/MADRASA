/**
 * ============================================================================
 * المحرك السحابي المتكامل لمنظومة النقاط والإدارة المدرسية الشاملة
 * Google Apps Script Backend Engine (Code.gs)
 * ============================================================================
 */

const SHEET_CONFIG = {
  School_Setup: {
    headers: ['ItemID', 'Category', 'Label', 'PointsValue', 'Type', 'Icon', 'Color'],
    headerBg: '#1E3A8A',
    headerFg: '#FFFFFF'
  },
  Teachers: {
    headers: ['TeacherID', 'TeacherName', 'PIN', 'Role', 'Subjects', 'AssignedSections'],
    headerBg: '#0F766E',
    headerFg: '#FFFFFF'
  },
  Students: {
    headers: ['StudentID', 'RollNumber', 'StudentName', 'Grade', 'Section', 'TotalPoints', 'AttendanceToday', 'ParentPhone'],
    headerBg: '#1D4ED8',
    headerFg: '#FFFFFF'
  },
  Points_Log: {
    headers: ['LogID', 'Timestamp', 'StudentID', 'TeacherID', 'Subject', 'Grade', 'Section', 'ActionCategory', 'ActionLabel', 'PointsDelta'],
    headerBg: '#047857',
    headerFg: '#FFFFFF'
  },
  Attendance_Log: {
    headers: ['RecordID', 'Date', 'Period', 'Grade', 'Section', 'StudentID', 'Status', 'TeacherID', 'Subject'],
    headerBg: '#B45309',
    headerFg: '#FFFFFF'
  },
  Notes_Log: {
    headers: ['NoteID', 'Timestamp', 'StudentID', 'TeacherID', 'Subject', 'Grade', 'Section', 'NoteType', 'NoteText'],
    headerBg: '#6D28D9',
    headerFg: '#FFFFFF'
  }
};

/**
 * 1. القائمة المخصصة داخل نافذة Google Sheets عند فتح الملف
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('⚙️ إدارة منظومة النقاط')
    .addItem('🏗️ بناء وتنسيق الأوراق الست تلقائياً', 'setupDatabaseSheets')
    .addItem('🆔 توليد المعرفات الناقصة للطلاب (StudentID)', 'generateMissingStudentIDs')
    .addSeparator()
    .addItem('📊 إصدار وتحديث تقرير الإحصائيات الشامل', 'generateSummaryReport')
    .addItem('✅ تصفير نقاط الطلاب (مع حفظ مشاركات ووظائف المعلمين)', 'resetPointsKeepTeacherCounts')
    .addItem('🔄 تصفير نقاط الفترة الحالية الشامل (مع أرشفة السجل)', 'resetPeriodPoints')
    .addSeparator()
    .addItem('🚀 إنشاء ملف منظومة جديد مستقل في Google Drive', 'createNewStandaloneSystem')
    .addToUi();
}

/**
 * 2. إنشاء ملف Google Sheet جديد بالكامل في حساب المستخدم بالبرمجة وطباعة رابطه
 */
function createNewStandaloneSystem() {
  const ss = SpreadsheetApp.create('قاعدة بيانات منظومة النقاط المدرسية الشاملة');
  setupDatabaseSheetsForSpreadsheet(ss, true);
  const url = ss.getUrl();
  Logger.log('تم إنشاء ملف المنظومة بنجاح! الرابط المباشر: ' + url);
  try {
    SpreadsheetApp.getUi().alert(
      '✅ تم إنشاء المنظومة بنجاح',
      'تم إنشاء وتنسيق ملف Google Sheets الجديد مع الأوراق الـ 6 والبيانات الأولية.\n\nالرابط:\n' + url,
      SpreadsheetApp.getUi().ButtonSet.OK
    );
  } catch (err) {
    // في حال التشغيل من محرر Apps Script مباشرة بدون واجهة شيت مفتوحة
    console.log('Spreadsheet URL: ' + url);
  }
  return url;
}

/**
 * 3. التهيئة التلقائية الشاملة لقاعدة البيانات (الأوراق الـ 6 + التنسيق + البيانات الافتراضية)
 */
function setupDatabaseSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const result = setupDatabaseSheetsForSpreadsheet(ss, true);
  try {
    SpreadsheetApp.getUi().alert(
      '✅ اكتملت التهيئة الشاملة',
      'تم بناء وتنسيق الأوراق الـ 6 وتجميد الترويسات وضبط المعادلات بنجاح.',
      SpreadsheetApp.getUi().ButtonSet.OK
    );
  } catch (e) {
    console.log(result.message);
  }
  return result;
}

function setupDatabaseSheetsForSpreadsheet(ss, seedIfEmpty) {
  const defaultData = getDefaultSeedData();
  const sheetNames = Object.keys(SHEET_CONFIG);

  sheetNames.forEach(function(sheetName) {
    const cfg = SHEET_CONFIG[sheetName];
    let sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
    }

    sheet.setRightToLeft(true);
    const headerRange = sheet.getRange(1, 1, 1, cfg.headers.length);
    headerRange.setValues([cfg.headers]);
    headerRange.setBackground(cfg.headerBg);
    headerRange.setFontColor(cfg.headerFg);
    headerRange.setFontWeight('bold');
    headerRange.setFontFamily('Cairo');
    headerRange.setFontSize(11);
    headerRange.setHorizontalAlignment('center');
    headerRange.setVerticalAlignment('middle');
    sheet.setRowHeight(1, 32);
    sheet.setFrozenRows(1);

    // تعبئة البيانات الأولية إذا كانت الورقة فارغة
    if (seedIfEmpty && sheet.getLastRow() <= 1 && defaultData[sheetName] && defaultData[sheetName].length > 0) {
      const rows = defaultData[sheetName];
      const dataRange = sheet.getRange(2, 1, rows.length, cfg.headers.length);
      dataRange.setValues(rows);
      dataRange.setFontFamily('Cairo');
      dataRange.setFontSize(10);
      dataRange.setVerticalAlignment('middle');
    }

    // في ورقة الطلاب: ضبط معادلات الرصيد التراكمي SUMIF تلقائياً
    if (sheetName === 'Students' && sheet.getLastRow() > 1) {
      const numRows = sheet.getLastRow() - 1;
      const formulas = [];
      for (let i = 0; i < numRows; i++) {
        const rowNum = i + 2;
        formulas.push(['=SUMIF(Points_Log!$C$2:$C$5000, A' + rowNum + ', Points_Log!$J$2:$J$5000)']);
      }
      sheet.getRange(2, 6, numRows, 1).setFormulas(formulas);
    }

    // ضبط عرض الأعمدة تلقائياً مع هامش مريح
    for (let col = 1; col <= cfg.headers.length; col++) {
      sheet.autoResizeColumn(col);
      const currentWidth = sheet.getColumnWidth(col);
      if (currentWidth < 120) {
        sheet.setColumnWidth(col, 130);
      } else if (currentWidth > 320) {
        sheet.setColumnWidth(col, 320);
      } else {
        sheet.setColumnWidth(col, currentWidth + 24);
      }
    }

    // حماية الترويسة الأولى تحذيرياً لمنع الحذف بالخطأ
    const protections = sheet.getProtections(SpreadsheetApp.ProtectionType.RANGE);
    if (protections.length === 0) {
      const protection = headerRange.protect().setDescription('حماية ترويسة ' + sheetName);
      protection.setWarningOnly(true);
    }
  });

  // حذف الورقة الافتراضية Sheet1 أو ورقة1 إن وجدت
  const allSheets = ss.getSheets();
  if (allSheets.length > sheetNames.length) {
    allSheets.forEach(function(sh) {
      const name = sh.getName();
      if (sheetNames.indexOf(name) === -1 && (name === 'Sheet1' || name === 'ورقة1' || name === 'ورقة 1')) {
        ss.deleteSheet(sh);
      }
    });
  }

  return {
    status: 'success',
    message: 'تم بناء وتهيئة الأوراق الـ 6 بنجاح',
    spreadsheetUrl: ss.getUrl()
  };
}

/**
 * 4. توليد المعرفات الناقصة للطلاب بصيغة فريدة وثابتة (مثل STD-801-001)
 */
function generateMissingStudentIDs() {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName('Students');
    if (!sheet || sheet.getLastRow() <= 1) {
      return { status: 'ok', updatedCount: 0 };
    }

    const lastRow = sheet.getLastRow();
    const range = sheet.getRange(2, 1, lastRow - 1, 8);
    const values = range.getValues();

    const existingIds = {};
    const sectionMaxSeq = {};
    const sectionRollCounter = {};

    // المسح الأول: حصر المعرفات الحالية وأعلى تسلسل لكل شعبة
    for (let i = 0; i < values.length; i++) {
      const sid = String(values[i][0] || '').trim();
      const secCode = formatSectionCode(String(values[i][4] || '8_1'));
      if (sid) {
        existingIds[sid] = true;
        const parts = sid.split('-');
        if (parts.length === 3) {
          const seqNum = parseInt(parts[2], 10);
          if (!isNaN(seqNum)) {
            sectionMaxSeq[secCode] = Math.max(sectionMaxSeq[secCode] || 0, seqNum);
          }
        }
      }
      const roll = parseInt(values[i][1], 10);
      if (!isNaN(roll)) {
        sectionRollCounter[secCode] = Math.max(sectionRollCounter[secCode] || 0, roll);
      }
    }

    let updatedCount = 0;
    for (let i = 0; i < values.length; i++) {
      const name = String(values[i][2] || '').trim();
      if (!name) continue;

      const secRaw = String(values[i][4] || '8_1').trim();
      const secCode = formatSectionCode(secRaw);

      // توليد الرقم التسلسلي داخل الشعبة إذا كان فارغاً
      if (!values[i][1]) {
        sectionRollCounter[secCode] = (sectionRollCounter[secCode] || 0) + 1;
        values[i][1] = sectionRollCounter[secCode];
      }

      // توليد StudentID إذا كان فارغاً
      let sid = String(values[i][0] || '').trim();
      if (!sid) {
        let nextSeq = (sectionMaxSeq[secCode] || 0) + 1;
        let candidate = 'STD-' + secCode + '-' + padNumber(nextSeq, 3);
        while (existingIds[candidate]) {
          nextSeq++;
          candidate = 'STD-' + secCode + '-' + padNumber(nextSeq, 3);
        }
        sectionMaxSeq[secCode] = nextSeq;
        existingIds[candidate] = true;
        values[i][0] = candidate;
        updatedCount++;
      }

      // الحالة الافتراضية للحضور
      if (!values[i][6]) {
        values[i][6] = 'حاضر';
      }
    }

    if (updatedCount > 0) {
      range.setValues(values);
      // إعادة تثبيت معادلات SUMIF في عمود TotalPoints
      for (let i = 0; i < values.length; i++) {
        const r = i + 2;
        sheet.getRange(r, 6).setFormula('=SUMIF(Points_Log!$C$2:$C$5000, A' + r + ', Points_Log!$J$2:$J$5000)');
      }
    }

    return { status: 'success', updatedCount: updatedCount };
  } finally {
    lock.releaseLock();
  }
}

/**
 * 5. تصفير نقاط الفترة الحالية مع حفظ نسخة أرشيفية من السجل
 */

/**
 * 5-ب. تصفير نقاط الطلاب فقط مع الاحتفاظ بعدد المشاركات والوظائف والتسميع للمعلمين
 */
function resetPointsKeepTeacherCounts() {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const logSheet = ss.getSheetByName('Points_Log');
    if (logSheet && logSheet.getLastRow() > 1) {
      const numRows = logSheet.getLastRow() - 1;
      const zeros = [];
      for (let i = 0; i < numRows; i++) {
        zeros.push([0]);
      }
      // تصفير عمود PointsDelta (العمود 10) مع الإبقاء على سجلات المشاركات والوظائف والتسميع للمعلمين
      logSheet.getRange(2, 10, numRows, 1).setValues(zeros);
    }
    return { status: 'success', message: 'تم تصفير أرصدة النقاط للطلاب مع الاحتفاظ الكامل بعدد المشاركات والوظائف للمعلمين.' };
  } finally {
    lock.releaseLock();
  }
}

function resetPeriodPoints() {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const logSheet = ss.getSheetByName('Points_Log');
    if (logSheet && logSheet.getLastRow() > 1) {
      const timestamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'GMT+3', 'yyyyMMdd_HHmm');
      const archiveSheet = logSheet.copyTo(ss);
      archiveSheet.setName('Archive_Points_' + timestamp);
      logSheet.deleteRows(2, logSheet.getLastRow() - 1);
    }

    const stdSheet = ss.getSheetByName('Students');
    if (stdSheet && stdSheet.getLastRow() > 1) {
      const numRows = stdSheet.getLastRow() - 1;
      const formulas = [];
      for (let i = 0; i < numRows; i++) {
        const r = i + 2;
        formulas.push(['=SUMIF(Points_Log!$C$2:$C$5000, A' + r + ', Points_Log!$J$2:$J$5000)']);
      }
      stdSheet.getRange(2, 6, numRows, 1).setFormulas(formulas);
    }

    return { status: 'success', message: 'تمت أرشفة السجل السابق وتصفير نقاط الفترة الحالية بنجاح.' };
  } finally {
    lock.releaseLock();
  }
}

/**
 * 6. إصدار ورقة تقرير إحصائي شامل داخل Google Sheets
 */
function generateSummaryReport() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let repSheet = ss.getSheetByName('Summary_Report');
  if (!repSheet) {
    repSheet = ss.insertSheet('Summary_Report');
  } else {
    repSheet.clear();
  }
  repSheet.setRightToLeft(true);

  const students = readSheetObjects(ss, 'Students');
  const logs = readSheetObjects(ss, 'Points_Log');
  const notes = readSheetObjects(ss, 'Notes_Log');

  const headers = [
    'StudentID', 'الاسم الكامل', 'الصف', 'الشعبة', 'الرصيد التراكمي',
    'تسميع شفهي', 'واجبات منجزة', 'مشاركات صفية', 'تنبيهات/تقصير', 'عدد الملاحظات', 'نسبة الالتزام %'
  ];

  repSheet.getRange(1, 1, 1, headers.length).setValues([headers])
    .setBackground('#0F172A').setFontColor('#FFFFFF').setFontWeight('bold').setHorizontalAlignment('center');
  repSheet.setFrozenRows(1);

  const reportRows = students.map(function(st) {
    const stLogs = logs.filter(function(l) { return String(l.StudentID) === String(st.StudentID); });
    const stNotes = notes.filter(function(n) { return String(n.StudentID) === String(st.StudentID); });
    let oral = 0, hw = 0, part = 0, neg = 0, posCount = 0;
    let totalPts = 0;

    stLogs.forEach(function(l) {
      const delta = Number(l.PointsDelta) || 0;
      totalPts += delta;
      if (delta > 0) posCount++;
      if (delta < 0) neg++;
      if (l.ActionCategory === 'oral') oral++;
      if (l.ActionCategory === 'homework' && delta > 0) hw++;
      if (l.ActionCategory === 'participation') part++;
    });

    const commitment = stLogs.length > 0 ? Math.round((posCount / stLogs.length) * 100) + '%' : '100%';
    return [
      st.StudentID, st.StudentName, st.Grade, st.Section, totalPts,
      oral, hw, part, neg, stNotes.length, commitment
    ];
  });

  if (reportRows.length > 0) {
    repSheet.getRange(2, 1, reportRows.length, headers.length).setValues(reportRows);
  }
  for (let c = 1; c <= headers.length; c++) {
    repSheet.autoResizeColumn(c);
  }

  return { status: 'success', rows: reportRows.length };
}

/**
 * 7. واجهة قراءة البيانات البرمجية (GET API)
 */
function doGet(e) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const action = (e && e.parameter && e.parameter.action) ? e.parameter.action : 'getAll';

    if (action === 'initDatabase') {
      const res = setupDatabaseSheetsForSpreadsheet(ss, true);
      return jsonResponse(res);
    }

    // التأكد من وجود الأوراق الست قبل القراءة
    setupDatabaseSheetsForSpreadsheet(ss, false);

    const payload = {
      status: 'success',
      timestamp: new Date().toISOString(),
      data: {
        School_Setup: readSheetObjects(ss, 'School_Setup'),
        Teachers: readSheetObjects(ss, 'Teachers'),
        Students: readSheetObjects(ss, 'Students'),
        Points_Log: readSheetObjects(ss, 'Points_Log'),
        Attendance_Log: readSheetObjects(ss, 'Attendance_Log'),
        Notes_Log: readSheetObjects(ss, 'Notes_Log')
      }
    };
    return jsonResponse(payload);
  } catch (err) {
    return jsonResponse({ status: 'error', message: err.toString() });
  }
}

/**
 * 8. واجهة كتابة ومزامنة البيانات البرمجية (POST API) محمية بـ LockService
 */
function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(25000);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const rawBody = (e && e.postData && e.postData.contents) ? e.postData.contents : '{}';
    const body = JSON.parse(rawBody);
    const action = body.action || '';

    // 1) تهيئة الشيت بالكامل بضغطة زر من واجهة الإدارة
    if (action === 'initDatabase') {
      const res = setupDatabaseSheetsForSpreadsheet(ss, true);
      return jsonResponse(res);
    }

    // 2) إضافة حركة نقاط جديدة أو دفعة حركات من طابور عدم الاتصال (Offline Queue Batch)
    if (action === 'addPointLog' || action === 'syncBatch') {
      const operations = action === 'syncBatch' ? (body.operations || []) : [body];
      let processed = 0;

      operations.forEach(function(op) {
        const opType = op.opType || op.action;
        if (opType === 'addPointLog') {
          appendRowToSheet(ss, 'Points_Log', [
            op.LogID || ('LOG-' + Date.now()),
            op.Timestamp || formatNow(),
            op.StudentID,
            op.TeacherID,
            op.Subject,
            op.Grade,
            op.Section,
            op.ActionCategory,
            op.ActionLabel,
            Number(op.PointsDelta) || 0
          ]);
          updateStudentPointsCache(ss, op.StudentID);
          processed++;
        } else if (opType === 'resetPointsKeepCounts') {
          resetPointsKeepTeacherCounts();
          processed++;
        } else if (opType === 'undoPointLog') {
          deleteRowById(ss, 'Points_Log', 1, op.LogID);
          updateStudentPointsCache(ss, op.StudentID);
          processed++;
        } else if (opType === 'logAttendance') {
          appendRowToSheet(ss, 'Attendance_Log', [
            op.RecordID || ('ATT-' + Date.now()),
            op.Date || formatToday(),
            Number(op.Period) || 1,
            op.Grade,
            op.Section,
            op.StudentID,
            op.Status,
            op.TeacherID,
            op.Subject
          ]);
          updateStudentAttendanceToday(ss, op.StudentID, op.Status);
          processed++;
        } else if (opType === 'addNote') {
          appendRowToSheet(ss, 'Notes_Log', [
            op.NoteID || ('NTE-' + Date.now()),
            op.Timestamp || formatNow(),
            op.StudentID,
            op.TeacherID,
            op.Subject,
            op.Grade,
            op.Section,
            op.NoteType,
            op.NoteText
          ]);
          processed++;
        }
      });

      return jsonResponse({ status: 'success', processed: processed });
    }

    // 3) حفظ جدول كامل من مركز الإدارة (CRUD Sync for Students, Teachers, School_Setup)
    if (action === 'saveTable') {
      const sheetName = body.sheetName;
      const rows = body.rows || [];
      if (!SHEET_CONFIG[sheetName]) {
        return jsonResponse({ status: 'error', message: 'اسم الورقة غير صالح: ' + sheetName });
      }
      overwriteSheetData(ss, sheetName, rows);
      if (sheetName === 'Students') {
        generateMissingStudentIDs();
      }
      return jsonResponse({ status: 'success', sheetName: sheetName, count: rows.length });
    }

    // 4) تصفير نقاط الفترة
    if (action === 'resetPeriodPoints') {
      return jsonResponse(resetPeriodPoints());
    }

    return jsonResponse({ status: 'error', message: 'إجراء غير معروف: ' + action });
  } catch (err) {
    return jsonResponse({ status: 'error', message: err.toString() });
  } finally {
    lock.releaseLock();
  }
}

/**
 * دوال مساعدة للقراءة والكتابة والتنسيق
 */
function readSheetObjects(ss, sheetName) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() <= 1) return [];
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const result = [];
  for (let r = 1; r < data.length; r++) {
    const row = data[r];
    if (row.every(function(cell) { return cell === '' || cell === null; })) continue;
    const obj = {};
    for (let c = 0; c < headers.length; c++) {
      obj[headers[c]] = row[c];
    }
    result.push(obj);
  }
  return result;
}

function appendRowToSheet(ss, sheetName, rowArray) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    setupDatabaseSheetsForSpreadsheet(ss, false);
    sheet = ss.getSheetByName(sheetName);
  }
  sheet.appendRow(rowArray);
}

function deleteRowById(ss, sheetName, idColIndex1Based, targetId) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() <= 1) return false;
  const ids = sheet.getRange(2, idColIndex1Based, sheet.getLastRow() - 1, 1).getValues();
  for (let i = ids.length - 1; i >= 0; i--) {
    if (String(ids[i][0]) === String(targetId)) {
      sheet.deleteRow(i + 2);
      return true;
    }
  }
  return false;
}

function updateStudentAttendanceToday(ss, studentId, status) {
  const sheet = ss.getSheetByName('Students');
  if (!sheet || sheet.getLastRow() <= 1) return;
  const ids = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(studentId)) {
      sheet.getRange(i + 2, 7).setValue(status);
      break;
    }
  }
}

function updateStudentPointsCache(ss, studentId) {
  const sheet = ss.getSheetByName('Students');
  if (!sheet || sheet.getLastRow() <= 1) return;
  const ids = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(studentId)) {
      const rowNum = i + 2;
      sheet.getRange(rowNum, 6).setFormula('=SUMIF(Points_Log!$C$2:$C$5000, A' + rowNum + ', Points_Log!$J$2:$J$5000)');
      break;
    }
  }
}

function overwriteSheetData(ss, sheetName, rowObjects) {
  const cfg = SHEET_CONFIG[sheetName];
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    setupDatabaseSheetsForSpreadsheet(ss, false);
    sheet = ss.getSheetByName(sheetName);
  }
  if (sheet.getLastRow() > 1) {
    sheet.deleteRows(2, sheet.getLastRow() - 1);
  }
  if (rowObjects.length === 0) return;

  const matrix = rowObjects.map(function(obj, idx) {
    return cfg.headers.map(function(h) {
      if (sheetName === 'Students' && h === 'TotalPoints') {
        const rNum = idx + 2;
        return '=SUMIF(Points_Log!$C$2:$C$5000, A' + rNum + ', Points_Log!$J$2:$J$5000)';
      }
      return obj[h] !== undefined ? obj[h] : '';
    });
  });

  sheet.getRange(2, 1, matrix.length, cfg.headers.length).setValues(matrix);
}

function formatSectionCode(sectionStr) {
  const parts = sectionStr.replace(/[^0-9_]/g, '').split('_');
  const g = parts[0] || '8';
  const s = parts[1] || '1';
  return g + padNumber(parseInt(s, 10) || 1, 2);
}

function padNumber(num, size) {
  let s = String(num);
  while (s.length < size) s = '0' + s;
  return s;
}

function formatNow() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'GMT+3', 'yyyy-MM-dd HH:mm');
}

function formatToday() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'GMT+3', 'yyyy-MM-dd');
}

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * البيانات الافتراضية الكاملة لبناء النظام السحابي
 */
function getDefaultSeedData() {
  return {
    School_Setup: [
      ['SET-01', 'setting', 'ثانوية الصحابة الشرعية', 0, 'neutral', '🏫', '#1E3A8A'],
      ['SET-02', 'setting', 'العام الدراسي 2026-2027 - الفصل الأول', 0, 'neutral', '📅', '#0F766E'],
      ['GRD-07', 'grade', 'السابع', 7, '7', '📚', '#3B82F6'],
      ['GRD-08', 'grade', 'الثامن', 8, '8', '📚', '#3B82F6'],
      ['GRD-09', 'grade', 'التاسع', 9, '9', '📚', '#3B82F6'],
      ['SEC-7_1', 'section', '7_1', 7, 'السابع', '🏫', '#2563EB'],
      ['SEC-7_2', 'section', '7_2', 7, 'السابع', '🏫', '#2563EB'],
      ['SEC-7_3', 'section', '7_3', 7, 'السابع', '🏫', '#2563EB'],
      ['SEC-8_1', 'section', '8_1', 8, 'الثامن', '🏫', '#2563EB'],
      ['SEC-8_2', 'section', '8_2', 8, 'الثامن', '🏫', '#2563EB'],
      ['SEC-9_1', 'section', '9_1', 9, 'التاسع', '🏫', '#2563EB'],
      ['SEC-9_2', 'section', '9_2', 9, 'التاسع', '🏫', '#2563EB'],
      ['SUB-01', 'subject', 'اجتماعيات', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-02', 'subject', 'أصول', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-03', 'subject', 'إنكليزي', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-04', 'subject', 'تجويد', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-05', 'subject', 'تفسير', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-06', 'subject', 'حديث', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-07', 'subject', 'حوار', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-08', 'subject', 'دعوة', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-09', 'subject', 'رياضة', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-10', 'subject', 'رياضيات', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-11', 'subject', 'سيرة', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-12', 'subject', 'شمائل', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-13', 'subject', 'عربي', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-14', 'subject', 'عقيدة', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-15', 'subject', 'علوم', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-16', 'subject', 'فرنسي', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-17', 'subject', 'فقه', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-18', 'subject', 'فلسفة', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-19', 'subject', 'فيزياء', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-20', 'subject', 'معلوماتية', 0, 'neutral', '📖', '#0D9488'],
      ['SUB-21', 'subject', 'نشاط', 0, 'neutral', '📖', '#0D9488'],
      ['EV-01', 'eval_rule', 'مشاركة', 1, 'positive', '✋', '#10B981'],
      ['EV-02', 'eval_rule', 'تسميع شفهي', 2, 'positive', '🎙️', '#059669'],
      ['EV-03', 'eval_rule', 'واجب كامل', 2, 'positive', '📘', '#2563EB'],
      ['EV-04', 'eval_rule', 'تميز وإبداع', 3, 'positive', '⭐', '#7C3AED'],
      ['EV-05', 'eval_rule', 'تقصير واجب', -1, 'negative', '⚠️', '#F59E0B'],
      ['EV-06', 'eval_rule', 'تنبيه سلوكي', -1, 'negative', '🚫', '#EF4444'],
      ['QN-01', 'quick_note', 'تسميع شفهي متميز', 0, 'positive', '🌟', '#10B981'],
      ['QN-02', 'quick_note', 'تفاعل ممتاز في الحصة', 0, 'positive', '👏', '#2563EB'],
      ['QN-03', 'quick_note', 'نسيان الكتاب أو الدفتر', 0, 'negative', '📕', '#F59E0B'],
      ['QN-04', 'quick_note', 'عدم كتابة الواجب', 0, 'negative', '📝', '#EF4444'],
      ['QN-05', 'quick_note', 'أحاديث جانبية أثناء الشرح', 0, 'negative', '🔇', '#DC2626']
    ],
    Teachers: [
      ['TCH-01', 'المدير العام', '1234', 'admin', 'اجتماعيات, أصول, إنكليزي, تجويد, تفسير, حديث, حوار, دعوة, رياضة, رياضيات, سيرة, شمائل, عربي, عقيدة, علوم, فرنسي, فقه, فلسفة, فيزياء, معلوماتية, نشاط', '7_1, 7_2, 7_3, 8_1, 8_2, 9_1, 9_2'],
      ['TCH-02', 'أ. محمود العلي', '1111', 'teacher', 'عربي, تجويد, تفسير, حديث', '7_1, 7_2, 7_3, 8_1'],
      ['TCH-03', 'أ. سامر الحسن', '2222', 'teacher', 'علوم, فيزياء, رياضيات, معلوماتية', '8_1, 8_2, 9_1, 9_2'],
      ['TCH-04', 'أ. طارق الزعبي', '3333', 'teacher', 'إنكليزي, فرنسي, حوار, نشاط', '7_1, 8_1, 9_1'],
      ['TCH-05', 'أ. ياسر الحموي', '4444', 'supervisor', 'اجتماعيات, فلسفة, رياضة', '7_2, 8_2, 9_2'],
      ['TCH-06', 'أ. نبيل الشامي', '5555', 'teacher', 'فقه, عقيدة, أصول, سيرة, شمائل, دعوة', '7_1, 7_2, 7_3, 8_1, 8_2, 9_1, 9_2']
    ],
    Students: [
      ['STD-701-001', 1, 'المجد معتصم جرجنازي', 'السابع', '7_1', 0, 'حاضر', '963944701001'],
      ['STD-701-002', 2, 'أنس الموسى', 'السابع', '7_1', 0, 'حاضر', '963944701002'],
      ['STD-701-003', 3, 'براء علي سلوم', 'السابع', '7_1', 0, 'حاضر', '963944701003'],
      ['STD-701-004', 4, 'تيم احمد طوغانجي', 'السابع', '7_1', 0, 'حاضر', '963944701004'],
      ['STD-701-005', 5, 'جواد محمود قطان', 'السابع', '7_1', 0, 'حاضر', '963944701005'],
      ['STD-701-006', 6, 'حسين علي البحاح', 'السابع', '7_1', 0, 'حاضر', '963944701006'],
      ['STD-701-007', 7, 'سراج مصطفى السنكري', 'السابع', '7_1', 0, 'حاضر', '963944701007'],
      ['STD-701-008', 8, 'سمير المذيبوب', 'السابع', '7_1', 0, 'حاضر', '963944701008'],
      ['STD-701-009', 9, 'عبد القادر احمد دالي بالطه', 'السابع', '7_1', 0, 'حاضر', '963944701009'],
      ['STD-701-010', 10, 'عبد الرزاق حنيظل', 'السابع', '7_1', 0, 'حاضر', '963944701010'],
      ['STD-701-011', 11, 'عبد العظيم خالد دالي بالطة', 'السابع', '7_1', 0, 'حاضر', '963944701011'],
      ['STD-701-012', 12, 'عبد الله نزار برادعي', 'السابع', '7_1', 0, 'حاضر', '963944701012'],
      ['STD-701-013', 13, 'علي عبد الرزاق الخضري', 'السابع', '7_1', 0, 'حاضر', '963944701013'],
      ['STD-701-014', 14, 'عمر مريد الفحام', 'السابع', '7_1', 0, 'حاضر', '963944701014'],
      ['STD-701-015', 15, 'عمران عبد المنعم معتوق', 'السابع', '7_1', 0, 'حاضر', '963944701015'],
      ['STD-701-016', 16, 'فاروق المغربي', 'السابع', '7_1', 0, 'حاضر', '963944701016'],
      ['STD-701-017', 17, 'محمد جود أنس عقاد', 'السابع', '7_1', 0, 'حاضر', '963944701017'],
      ['STD-701-018', 18, 'محمد طلال مليشو', 'السابع', '7_1', 0, 'حاضر', '963944701018'],
      ['STD-701-019', 19, 'محمد عرواني', 'السابع', '7_1', 0, 'حاضر', '963944701019'],
      ['STD-701-020', 20, 'محمد عيد خالد دويك', 'السابع', '7_1', 0, 'حاضر', '963944701020'],
      ['STD-701-021', 21, 'محمد قتيبة فرج', 'السابع', '7_1', 0, 'حاضر', '963944701021'],
      ['STD-701-022', 22, 'محمد قيس هيثم لطفي', 'السابع', '7_1', 0, 'حاضر', '963944701022'],
      ['STD-701-023', 23, 'محمد نور سعد الصليعي', 'السابع', '7_1', 0, 'حاضر', '963944701023'],
      ['STD-701-024', 24, 'محمد نور ورار', 'السابع', '7_1', 0, 'حاضر', '963944701024'],
      ['STD-701-025', 25, 'مزن قفورة', 'السابع', '7_1', 0, 'حاضر', '963944701025'],
      ['STD-701-026', 26, 'نعسان أحمد عثمان', 'السابع', '7_1', 0, 'حاضر', '963944701026'],
      ['STD-701-027', 27, 'ياسر الأمين', 'السابع', '7_1', 0, 'حاضر', '963944701027'],
      ['STD-702-001', 1, 'احمد باسل بهاء الياسين', 'السابع', '7_2', 0, 'حاضر', '963944702001'],
      ['STD-702-002', 2, 'اسامه احمد النصر', 'السابع', '7_2', 0, 'حاضر', '963944702002'],
      ['STD-702-003', 3, 'امير محمود المعراوي', 'السابع', '7_2', 0, 'حاضر', '963944702003'],
      ['STD-702-004', 4, 'اياد اسالم الحمصي', 'السابع', '7_2', 0, 'حاضر', '963944702004'],
      ['STD-702-005', 5, 'إبراهيم حجازي', 'السابع', '7_2', 0, 'حاضر', '963944702005'],
      ['STD-702-006', 6, 'أحمد نذير مهاوش', 'السابع', '7_2', 0, 'حاضر', '963944702006'],
      ['STD-702-007', 7, 'براء محمد أمين حاتم', 'السابع', '7_2', 0, 'حاضر', '963944702007'],
      ['STD-702-008', 8, 'حذيفه هيثم حايك', 'السابع', '7_2', 0, 'حاضر', '963944702008'],
      ['STD-702-009', 9, 'حسين علاء الدين الجمعه', 'السابع', '7_2', 0, 'حاضر', '963944702009'],
      ['STD-702-010', 10, 'صهيب عكرة', 'السابع', '7_2', 0, 'حاضر', '963944702010'],
      ['STD-702-011', 11, 'طارق ماهر حمصي', 'السابع', '7_2', 0, 'حاضر', '963944702011'],
      ['STD-702-012', 12, 'عبد الباري أيمن السراقبي', 'السابع', '7_2', 0, 'حاضر', '963944702012'],
      ['STD-702-013', 13, 'عبد الرحمن ياسر الحيصية', 'السابع', '7_2', 0, 'حاضر', '963944702013'],
      ['STD-702-014', 14, 'عبد الرزاق ممدوح صواف', 'السابع', '7_2', 0, 'حاضر', '963944702014'],
      ['STD-702-015', 15, 'عبد الملك ايمن المصري', 'السابع', '7_2', 0, 'حاضر', '963944702015'],
      ['STD-702-016', 16, 'عبد الملك مصطفى حسون', 'السابع', '7_2', 0, 'حاضر', '963944702016'],
      ['STD-702-017', 17, 'عبد الهادي حمزه البوشي', 'السابع', '7_2', 0, 'حاضر', '963944702017'],
      ['STD-702-018', 18, 'عبد هلا سعيد تليتي', 'السابع', '7_2', 0, 'حاضر', '963944702018'],
      ['STD-702-019', 19, 'عبد الهادي العاصي', 'السابع', '7_2', 0, 'حاضر', '963944702019'],
      ['STD-702-020', 20, 'ليث عزام الكوكو', 'السابع', '7_2', 0, 'حاضر', '963944702020'],
      ['STD-702-021', 21, 'مالك عامر مغربل', 'السابع', '7_2', 0, 'حاضر', '963944702021'],
      ['STD-702-022', 22, 'ماهر علاء الدين بظ', 'السابع', '7_2', 0, 'حاضر', '963944702022'],
      ['STD-702-023', 23, 'محمد غياث صالح', 'السابع', '7_2', 0, 'حاضر', '963944702023'],
      ['STD-702-024', 24, 'محمود فرداوي', 'السابع', '7_2', 0, 'حاضر', '963944702024'],
      ['STD-702-025', 25, 'مصطفى الجمعه', 'السابع', '7_2', 0, 'حاضر', '963944702025'],
      ['STD-702-026', 26, 'مصطفى الحاج إبراهيم', 'السابع', '7_2', 0, 'حاضر', '963944702026'],
      ['STD-702-027', 27, 'مصطفى مهند العطار', 'السابع', '7_2', 0, 'حاضر', '963944702027'],
      ['STD-702-028', 28, 'نجم أشرف نجيم', 'السابع', '7_2', 0, 'حاضر', '963944702028'],
      ['STD-702-029', 29, 'يزن المصطفى', 'السابع', '7_2', 0, 'حاضر', '963944702029'],
      ['STD-703-001', 1, 'إياد الخياط', 'السابع', '7_3', 0, 'حاضر', '963944703001'],
      ['STD-703-002', 2, 'إياد مكاوي', 'السابع', '7_3', 0, 'حاضر', '963944703002'],
      ['STD-703-003', 3, 'أنس بشار بحري', 'السابع', '7_3', 0, 'حاضر', '963944703003'],
      ['STD-703-004', 4, 'أنس هيثم خلوف', 'السابع', '7_3', 0, 'حاضر', '963944703004'],
      ['STD-703-005', 5, 'تيم الخالد', 'السابع', '7_3', 0, 'حاضر', '963944703005'],
      ['STD-703-006', 6, 'تيم محمد جركس', 'السابع', '7_3', 0, 'حاضر', '963944703006'],
      ['STD-703-007', 7, 'حمدو محمود خليف', 'السابع', '7_3', 0, 'حاضر', '963944703007'],
      ['STD-703-008', 8, 'خالد مهير', 'السابع', '7_3', 0, 'حاضر', '963944703008'],
      ['STD-703-009', 9, 'زيد عبد الوهاب الأصفر', 'السابع', '7_3', 0, 'حاضر', '963944703009'],
      ['STD-703-010', 10, 'سليمان السراقبي', 'السابع', '7_3', 0, 'حاضر', '963944703010'],
      ['STD-703-011', 11, 'صالح عبد الكافي قرواني', 'السابع', '7_3', 0, 'حاضر', '963944703011'],
      ['STD-703-012', 12, 'عبد الجبار بسام الراشد', 'السابع', '7_3', 0, 'حاضر', '963944703012'],
      ['STD-703-013', 13, 'عبد الرحمن محمد كنفوش', 'السابع', '7_3', 0, 'حاضر', '963944703013'],
      ['STD-703-014', 14, 'عبد السلام عزام هنو', 'السابع', '7_3', 0, 'حاضر', '963944703014'],
      ['STD-703-015', 15, 'عبد اللطيف محمد بارودي', 'السابع', '7_3', 0, 'حاضر', '963944703015'],
      ['STD-703-016', 16, 'عبد الرحمن السبسبي', 'السابع', '7_3', 0, 'حاضر', '963944703016'],
      ['STD-703-017', 17, 'عبدالله المصول', 'السابع', '7_3', 0, 'حاضر', '963944703017'],
      ['STD-703-018', 18, 'عدنان حسين الهويش', 'السابع', '7_3', 0, 'حاضر', '963944703018'],
      ['STD-703-019', 19, 'عدي زعيزع', 'السابع', '7_3', 0, 'حاضر', '963944703019'],
      ['STD-703-020', 20, 'عدي الشامي', 'السابع', '7_3', 0, 'حاضر', '963944703020'],
      ['STD-703-021', 21, 'عمر الخليل', 'السابع', '7_3', 0, 'حاضر', '963944703021'],
      ['STD-703-022', 22, 'قصي مازن الور', 'السابع', '7_3', 0, 'حاضر', '963944703022'],
      ['STD-703-023', 23, 'ليث مغمومة', 'السابع', '7_3', 0, 'حاضر', '963944703023'],
      ['STD-703-024', 24, 'مالك نادر عرواني', 'السابع', '7_3', 0, 'حاضر', '963944703024'],
      ['STD-703-025', 25, 'محمد شادي بارودي', 'السابع', '7_3', 0, 'حاضر', '963944703025'],
      ['STD-703-026', 26, 'محمد كنعان', 'السابع', '7_3', 0, 'حاضر', '963944703026'],
      ['STD-703-027', 27, 'منير نور الدين كوجك', 'السابع', '7_3', 0, 'حاضر', '963944703027'],
      ['STD-703-028', 28, 'نجم جواش', 'السابع', '7_3', 0, 'حاضر', '963944703028'],
      ['STD-703-029', 29, 'يوسف حامد الخياط', 'السابع', '7_3', 0, 'حاضر', '963944703029'],
      ['STD-801-001', 1, 'إياد الحمو', 'الثامن', '8_1', 0, 'حاضر', '963944801001'],
      ['STD-801-002', 2, 'أحمد جواد', 'الثامن', '8_1', 0, 'حاضر', '963944801002'],
      ['STD-801-003', 3, 'أمجد الوقاع', 'الثامن', '8_1', 0, 'حاضر', '963944801003'],
      ['STD-801-004', 4, 'أمجد طيبياني', 'الثامن', '8_1', 0, 'حاضر', '963944801004'],
      ['STD-801-005', 5, 'أمير البيات', 'الثامن', '8_1', 0, 'حاضر', '963944801005'],
      ['STD-801-006', 6, 'حمزة الدهش', 'الثامن', '8_1', 0, 'حاضر', '963944801006'],
      ['STD-801-007', 7, 'حمزة برادعي', 'الثامن', '8_1', 0, 'حاضر', '963944801007'],
      ['STD-801-008', 8, 'حمزة بظ', 'الثامن', '8_1', 0, 'حاضر', '963944801008'],
      ['STD-801-009', 9, 'خالد حاج حمدو', 'الثامن', '8_1', 0, 'حاضر', '963944801009'],
      ['STD-801-010', 10, 'خليف عمر خليف', 'الثامن', '8_1', 0, 'حاضر', '963944801010'],
      ['STD-801-011', 11, 'خليل عتيق', 'الثامن', '8_1', 0, 'حاضر', '963944801011'],
      ['STD-801-012', 12, 'ريان الجسري', 'الثامن', '8_1', 0, 'حاضر', '963944801012'],
      ['STD-801-013', 13, 'زكريا إدلبي', 'الثامن', '8_1', 0, 'حاضر', '963944801013'],
      ['STD-801-014', 14, 'سمير معراوي', 'الثامن', '8_1', 0, 'حاضر', '963944801014'],
      ['STD-801-015', 15, 'طه جنيدي', 'الثامن', '8_1', 0, 'حاضر', '963944801015'],
      ['STD-801-016', 16, 'عبد الرحمن قويدر', 'الثامن', '8_1', 0, 'حاضر', '963944801016'],
      ['STD-801-017', 17, 'عبد السلام الخراط', 'الثامن', '8_1', 0, 'حاضر', '963944801017'],
      ['STD-801-018', 18, 'عبد العزيز طلاع', 'الثامن', '8_1', 0, 'حاضر', '963944801018'],
      ['STD-801-019', 19, 'عبد القادر مليشو', 'الثامن', '8_1', 0, 'حاضر', '963944801019'],
      ['STD-801-020', 20, 'عبد الله العبد الله', 'الثامن', '8_1', 0, 'حاضر', '963944801020'],
      ['STD-801-021', 21, 'عبد الله العيسى', 'الثامن', '8_1', 0, 'حاضر', '963944801021'],
      ['STD-801-022', 22, 'عبد المعين عتيق', 'الثامن', '8_1', 0, 'حاضر', '963944801022'],
      ['STD-801-023', 23, 'عبد الملك الصالح', 'الثامن', '8_1', 0, 'حاضر', '963944801023'],
      ['STD-801-024', 24, 'عبد الهادي سبسببي', 'الثامن', '8_1', 0, 'حاضر', '963944801024'],
      ['STD-801-025', 25, 'قيس نجار', 'الثامن', '8_1', 0, 'حاضر', '963944801025'],
      ['STD-801-026', 26, 'ماهر خالد الزينة', 'الثامن', '8_1', 0, 'حاضر', '963944801026'],
      ['STD-801-027', 27, 'مجاهد الأصفر', 'الثامن', '8_1', 0, 'حاضر', '963944801027'],
      ['STD-801-028', 28, 'محمد أمير ديري', 'الثامن', '8_1', 0, 'حاضر', '963944801028'],
      ['STD-801-029', 29, 'محمد بابولي', 'الثامن', '8_1', 0, 'حاضر', '963944801029'],
      ['STD-801-030', 30, 'محمد بسام جمال', 'الثامن', '8_1', 0, 'حاضر', '963944801030'],
      ['STD-801-031', 31, 'محمد جوخدار', 'الثامن', '8_1', 0, 'حاضر', '963944801031'],
      ['STD-801-032', 32, 'محمد نجم الشاوي', 'الثامن', '8_1', 0, 'حاضر', '963944801032'],
      ['STD-801-033', 33, 'محمد يمان عساني', 'الثامن', '8_1', 0, 'حاضر', '963944801033'],
      ['STD-801-034', 34, 'مصطفى الحسن', 'الثامن', '8_1', 0, 'حاضر', '963944801034'],
      ['STD-801-035', 35, 'معتصم بالله الخاني', 'الثامن', '8_1', 0, 'حاضر', '963944801035'],
      ['STD-801-036', 36, 'يزن أوغلي', 'الثامن', '8_1', 0, 'حاضر', '963944801036'],
      ['STD-802-001', 1, 'إبراهيم الحمصي', 'الثامن', '8_2', 0, 'حاضر', '963944802001'],
      ['STD-802-002', 2, 'أنس المعطي', 'الثامن', '8_2', 0, 'حاضر', '963944802002'],
      ['STD-802-003', 3, 'أيهم بولاد', 'الثامن', '8_2', 0, 'حاضر', '963944802003'],
      ['STD-802-004', 4, 'أيهم قنوت', 'الثامن', '8_2', 0, 'حاضر', '963944802004'],
      ['STD-802-005', 5, 'زياد طرشان', 'الثامن', '8_2', 0, 'حاضر', '963944802005'],
      ['STD-802-006', 6, 'سعد الدين هبهاب', 'الثامن', '8_2', 0, 'حاضر', '963944802006'],
      ['STD-802-007', 7, 'سيف الدين حلبية', 'الثامن', '8_2', 0, 'حاضر', '963944802007'],
      ['STD-802-008', 8, 'عبد الباري عبدي', 'الثامن', '8_2', 0, 'حاضر', '963944802008'],
      ['STD-802-009', 9, 'عبد الرحمن الحايك', 'الثامن', '8_2', 0, 'حاضر', '963944802009'],
      ['STD-802-010', 10, 'عبد الرحمن عتيق', 'الثامن', '8_2', 0, 'حاضر', '963944802010'],
      ['STD-802-011', 11, 'عبد الرحمن معطي', 'الثامن', '8_2', 0, 'حاضر', '963944802011'],
      ['STD-802-012', 12, 'عثمان سراقبي', 'الثامن', '8_2', 0, 'حاضر', '963944802012'],
      ['STD-802-013', 13, 'علي الخياط', 'الثامن', '8_2', 0, 'حاضر', '963944802013'],
      ['STD-802-014', 14, 'علي خابور', 'الثامن', '8_2', 0, 'حاضر', '963944802014'],
      ['STD-802-015', 15, 'عمر الأعمى', 'الثامن', '8_2', 0, 'حاضر', '963944802015'],
      ['STD-802-016', 16, 'عمر العمر', 'الثامن', '8_2', 0, 'حاضر', '963944802016'],
      ['STD-802-017', 17, 'عمر المراد', 'الثامن', '8_2', 0, 'حاضر', '963944802017'],
      ['STD-802-018', 18, 'عمر جواد', 'الثامن', '8_2', 0, 'حاضر', '963944802018'],
      ['STD-802-019', 19, 'عمر خالد ضمان', 'الثامن', '8_2', 0, 'حاضر', '963944802019'],
      ['STD-802-020', 20, 'عمر منجد', 'الثامن', '8_2', 0, 'حاضر', '963944802020'],
      ['STD-802-021', 21, 'غيث المحمد', 'الثامن', '8_2', 0, 'حاضر', '963944802021'],
      ['STD-802-022', 22, 'قتيبة كمالة', 'الثامن', '8_2', 0, 'حاضر', '963944802022'],
      ['STD-802-023', 23, 'محمد الصمصام', 'الثامن', '8_2', 0, 'حاضر', '963944802023'],
      ['STD-802-024', 24, 'محمد عبدو دالي بالطة', 'الثامن', '8_2', 0, 'حاضر', '963944802024'],
      ['STD-802-025', 25, 'محمد علاء آغا', 'الثامن', '8_2', 0, 'حاضر', '963944802025'],
      ['STD-802-026', 26, 'محمد عوض فرزاد', 'الثامن', '8_2', 0, 'حاضر', '963944802026'],
      ['STD-802-027', 27, 'محمد قزيز', 'الثامن', '8_2', 0, 'حاضر', '963944802027'],
      ['STD-802-028', 28, 'محمد نصر الكيالي', 'الثامن', '8_2', 0, 'حاضر', '963944802028'],
      ['STD-802-029', 29, 'محمد نور غزال', 'الثامن', '8_2', 0, 'حاضر', '963944802029'],
      ['STD-802-030', 30, 'محمود العبسي', 'الثامن', '8_2', 0, 'حاضر', '963944802030'],
      ['STD-802-031', 31, 'محمود قويدر', 'الثامن', '8_2', 0, 'حاضر', '963944802031'],
      ['STD-802-032', 32, 'مصعب فروج', 'الثامن', '8_2', 0, 'حاضر', '963944802032'],
      ['STD-802-033', 33, 'معتصم نجم', 'الثامن', '8_2', 0, 'حاضر', '963944802033'],
      ['STD-802-034', 34, 'معد عدي', 'الثامن', '8_2', 0, 'حاضر', '963944802034'],
      ['STD-802-035', 35, 'منار الخاني', 'الثامن', '8_2', 0, 'حاضر', '963944802035'],
      ['STD-901-001', 1, 'إسماعيل كيالي', 'التاسع', '9_1', 0, 'حاضر', '963944901001'],
      ['STD-901-002', 2, 'أحمد مخاص المصري', 'التاسع', '9_1', 0, 'حاضر', '963944901002'],
      ['STD-901-003', 3, 'أغيد محمد الحلبي', 'التاسع', '9_1', 0, 'حاضر', '963944901003'],
      ['STD-901-004', 4, 'أيهم الوقاع', 'التاسع', '9_1', 0, 'حاضر', '963944901004'],
      ['STD-901-005', 5, 'أيهم بريك', 'التاسع', '9_1', 0, 'حاضر', '963944901005'],
      ['STD-901-006', 6, 'بكر محمد كفري', 'التاسع', '9_1', 0, 'حاضر', '963944901006'],
      ['STD-901-007', 7, 'حسين السبسبي', 'التاسع', '9_1', 0, 'حاضر', '963944901007'],
      ['STD-901-008', 8, 'خالد العزي', 'التاسع', '9_1', 0, 'حاضر', '963944901008'],
      ['STD-901-009', 9, 'عبد الرحمن الأصفر', 'التاسع', '9_1', 0, 'حاضر', '963944901009'],
      ['STD-901-010', 10, 'عبد الكريم حنيظل', 'التاسع', '9_1', 0, 'حاضر', '963944901010'],
      ['STD-901-011', 11, 'عبدالعزيز نشار', 'التاسع', '9_1', 0, 'حاضر', '963944901011'],
      ['STD-901-012', 12, 'عبدالله العلي', 'التاسع', '9_1', 0, 'حاضر', '963944901012'],
      ['STD-901-013', 13, 'عبيدة ريحان', 'التاسع', '9_1', 0, 'حاضر', '963944901013'],
      ['STD-901-014', 14, 'عماد أورفلي', 'التاسع', '9_1', 0, 'حاضر', '963944901014'],
      ['STD-901-015', 15, 'عمر المصري', 'التاسع', '9_1', 0, 'حاضر', '963944901015'],
      ['STD-901-016', 16, 'عمر أنور الملي', 'التاسع', '9_1', 0, 'حاضر', '963944901016'],
      ['STD-901-017', 17, 'غيث سعيد صوي', 'التاسع', '9_1', 0, 'حاضر', '963944901017'],
      ['STD-901-018', 18, 'فاروق حنيظل', 'التاسع', '9_1', 0, 'حاضر', '963944901018'],
      ['STD-901-019', 19, 'فداء ياسر الدين بيطار', 'التاسع', '9_1', 0, 'حاضر', '963944901019'],
      ['STD-901-020', 20, 'فواز أبو الطواقي', 'التاسع', '9_1', 0, 'حاضر', '963944901020'],
      ['STD-901-021', 21, 'محمد تمام شيخ غنامة', 'التاسع', '9_1', 0, 'حاضر', '963944901021'],
      ['STD-901-022', 22, 'محمد خير المصري', 'التاسع', '9_1', 0, 'حاضر', '963944901022'],
      ['STD-901-023', 23, 'محمد علي حجازي', 'التاسع', '9_1', 0, 'حاضر', '963944901023'],
      ['STD-901-024', 24, 'محمد فرحان بغدادي', 'التاسع', '9_1', 0, 'حاضر', '963944901024'],
      ['STD-901-025', 25, 'محمد ماجد حجازي', 'التاسع', '9_1', 0, 'حاضر', '963944901025'],
      ['STD-901-026', 26, 'مراد النايف', 'التاسع', '9_1', 0, 'حاضر', '963944901026'],
      ['STD-901-027', 27, 'يوسف الأعمى', 'التاسع', '9_1', 0, 'حاضر', '963944901027'],
      ['STD-902-001', 1, 'أحمد الكردي', 'التاسع', '9_2', 0, 'حاضر', '963944902001'],
      ['STD-902-002', 2, 'أحمد زريق', 'التاسع', '9_2', 0, 'حاضر', '963944902002'],
      ['STD-902-003', 3, 'أحمد زوزة', 'التاسع', '9_2', 0, 'حاضر', '963944902003'],
      ['STD-902-004', 4, 'أمجد عاشور', 'التاسع', '9_2', 0, 'حاضر', '963944902004'],
      ['STD-902-005', 5, 'بيهس بارودي', 'التاسع', '9_2', 0, 'حاضر', '963944902005'],
      ['STD-902-006', 6, 'حذيفة شادي إدلبي', 'التاسع', '9_2', 0, 'حاضر', '963944902006'],
      ['STD-902-007', 7, 'حسن الشيخ طه', 'التاسع', '9_2', 0, 'حاضر', '963944902007'],
      ['STD-902-008', 8, 'خالد كرزون', 'التاسع', '9_2', 0, 'حاضر', '963944902008'],
      ['STD-902-009', 9, 'رئيف سفاف', 'التاسع', '9_2', 0, 'حاضر', '963944902009'],
      ['STD-902-010', 10, 'سراج جرننازي', 'التاسع', '9_2', 0, 'حاضر', '963944902010'],
      ['STD-902-011', 11, 'شاكر حذيفة الديري', 'التاسع', '9_2', 0, 'حاضر', '963944902011'],
      ['STD-902-012', 12, 'عدنان بحري', 'التاسع', '9_2', 0, 'حاضر', '963944902012'],
      ['STD-902-013', 13, 'عدنان خالد', 'التاسع', '9_2', 0, 'حاضر', '963944902013'],
      ['STD-902-014', 14, 'عدنان صوي', 'التاسع', '9_2', 0, 'حاضر', '963944902014'],
      ['STD-902-015', 15, 'عمار فحلة', 'التاسع', '9_2', 0, 'حاضر', '963944902015'],
      ['STD-902-016', 16, 'عمر دبساوي', 'التاسع', '9_2', 0, 'حاضر', '963944902016'],
      ['STD-902-017', 17, 'فداء محمد دويك', 'التاسع', '9_2', 0, 'حاضر', '963944902017'],
      ['STD-902-018', 18, 'محمد معتوق', 'التاسع', '9_2', 0, 'حاضر', '963944902018'],
      ['STD-902-019', 19, 'محمد نور البيات', 'التاسع', '9_2', 0, 'حاضر', '963944902019'],
      ['STD-902-020', 20, 'محمد وليد نجار', 'التاسع', '9_2', 0, 'حاضر', '963944902020'],
      ['STD-902-021', 21, 'محمود كعيد', 'التاسع', '9_2', 0, 'حاضر', '963944902021'],
      ['STD-902-022', 22, 'يوسف المصطفى', 'التاسع', '9_2', 0, 'حاضر', '963944902022']
    ],
    Points_Log: [],
    Attendance_Log: [],
    Notes_Log: []
  };
}
